document.addEventListener('DOMContentLoaded', () => {
  const file = document.querySelector('input[type=file]');
  if (file) {
    file.addEventListener('change', () => {
      if (file.files[0] && file.files[0].size > 10 * 1024 * 1024) {
        alert('Please select an image smaller than 10 MB.');
        file.value = '';
      }
    });
  }
});
